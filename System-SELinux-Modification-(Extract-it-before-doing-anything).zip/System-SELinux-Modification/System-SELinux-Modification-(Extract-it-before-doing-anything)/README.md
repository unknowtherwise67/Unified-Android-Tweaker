## INTRODUCTIONS:
# Unified-Android-Tweaker:
- An Android All-In-One, Universal, Customized Mods and Tweaks Root Module. Install, Reboot and Forget.
- Feature:
- Fine-tune Android System/User/Kernel Settings, Tunables and Parameters.
- Configurable ZRAM Swap Virtual Memory (Improve system performance and system multitaskings in some cases).
- Developed and designed for user-configurables.
- Non-intrusive and systemless (Except system_settings).
- Open-Source complilance.

# System-Thermal-Modification:
- Force System to use OS Kernel-Based Thermal Managements System while maintain device hardware safety.

# System-SELinux-Modification:
- Change Android System Built-in SELinux to either Enforcing or Permissive. Configurable and by user's choice. SELinux (in Linux ecosystems) are work like Exploit Protection and with Hardened Security. Note that modify it can come with risks of OS Security while it can help solve problems for other like Root Modules, Apps, Software, etc.

## REQUIREMENTS/COMPATIBILITY:
- Android 6 and/or Above.
- Linux Kernel 3 and/or Above.
- UNLOCKED BOOTLOADER and Installed ROOT (Magisk - Version 20 and Above, KernelSU, etc).
- Zygisk or similar supports if its better (Optional).
- Knowledges of technologies and experiences.
- Should work and only on any Android platforms/devices (Emulators/Virtual may possible but functionals is not guaranteed).

## DISCLAMERS:
- MAKE USE OF THE ROOT MODULE AT YOUR OWN RISKS.
- DEVELOPERS ARE DOES NOT TOOK RESPONSIBILITY FOR WHAT HAPPENED ONLY IF IS YOUR FAULTS.

## INSTALLATIONS:
1. Install in any Root like Magisk, KernelSU, etc.
2. Reboot.
5. Have fun. :)

## CAUTIONS:
- Don't install with any tweaks root modules as it can cause the conflicts.
- Advise you should check other root modules if they are causing problems/issues before try pointing out both of my root module.

## TROUBLESHOOTS - IF PROBLEMS OCCURED:
### Hardware Buttons Methods:
- Turn off the device, keep holding power button until it bootup - show the device's logo twice and all Root Module will be automatically removed/disabled by Root (Magisk, KernelSU, etc).
### By ADB and Fastboot Commands:
1. Get the stock "boot.img" from Android Firmware of your device are currently using it.
2. Reboot to Fastboot/Bootloader Mode and do "fastboot flash boot <the boot.img> to "Boot" partition, or use Recovery Mode that allow to install it.
3. Reboot and to Setting, enable Developers Option, USB Debugging and Rooted Debugging.
4. Open and use ADB/Fastboot Command/Terminal or any shell command apps with ADB capability.
5. Enter "adb root" and "adb shell"
6. Enter "cd /data/adb"
7. Enter "ls"
8. Enter "rm -r <enter_the_module_folder_if_it's_there> to execute the removal command of that designated folders, including any items in it.
9. Reboot to Fastboot/Bootloader or Recovery Mode and reflash the Root Tool then reboot and see the result.

## NOTES:
- If you do like my work, buy me a coffee or donate and I'll thank you later. :D
- I will try to keep module up-to-date as possible and you can support if you want.
- You are free to fork the repository, but please MAKE SURE to add CREDITS or get rekt and don't forget to extract any archives that may necessary if you going to do things.

## Credits:
- [tytydrago](https://github.com/tytydraco): KTweak.
- [reiryuki](https://github.com/reiryuki): ZRAM Swap Configurator.
- [topjohnwu](https://github.com/topjohnwu): MagiskROOT, Zygisk, Root Module Platforms, SuperUser and MagiskBOOT.
- [tiann](https://github.com/tiann): KernelSU ROOT and other features from Magisk.
- [osm0sis](https://github.com/osm0sis): Installable ZIPs and other stuffs.
- And to some unknows Chinese users/persons or whoever it is for the "thermal" source codes and files.

- Since 8/30/2024
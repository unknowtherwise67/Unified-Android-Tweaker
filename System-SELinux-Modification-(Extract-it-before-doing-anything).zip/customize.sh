# Log the date and time
echo "- Time of execution: $(date)"

# Installations
ui_print ""
ui_print "- Preparing..."
ui_print "- Installing..."

# Kernel Tweaks
ui_print ""
ui_print "- Fine-tunning Android System/User/Kernel settings, tunables and other parameters..."
sh $MODPATH/system_files_chmods-1.sh
sh $MODPATH/system_selinux.sh
sh $MODPATH/system_settings.sh
sh $MODPATH/system_governors.sh
sh $MODPATH/system_kernel.sh
sh $MODPATH/system_cpu_gpu_power.sh
sh $MODPATH/system_files_chmods-2.sh
ui_print "- Completed."

# ZRAM/Swap Virtual Memory
ui_print ""
ZRAM=$MODPATH/system_virtual_memory.sh
if [ ! -f $ZRAM ]; then
  touch $ZRAM
fi
PROP=`grep_prop zram.resize $ZRAM`
ZRAM=/block/zram0
if [ "$PROP" == 0 ]; then
  ui_print "- System ZRAM/Swap Virtual Memory will be DISABLED."
  LMK=false
else
  FILE=/sys$ZRAM/disksize
  ui_print "- Modifying $FILE..."
  sed -i 's|#o||g' $MODPATH/service.sh
  if echo "$PROP" | grep -q %; then
    ui_print "- To $PROP of ZRAM/Swap Virtual Memory..."
    PROP=`echo "$PROP" | sed 's|%||g'`
    sed -i "s|VAR|$PROP|g" $MODPATH/service.sh
    sed -i 's|#%||g' $MODPATH/service.sh
  elif [ "$PROP" ]; then
    ui_print "- To $PROP of ZRAM/Swap Virtual Memory..."
    sed -i "s|DISKSIZE=1G|DISKSIZE=$PROP|g" $MODPATH/service.sh
  else
    ui_print "- To 1GBs of ZRAM/Swap Virtual Memory..."
  fi
  PROP=`grep_prop zram.algo $ZRAM`
  if [ "$PROP" ]; then
    FILE=/sys$ZRAM/comp_algorithm
    if grep -q "$PROP" $FILE; then
      ui_print "- Modifying $FILE..."
      ui_print "- To $PROP..."
      sed -i "s|ALGO=|ALGO=$PROP|g" $MODPATH/service.sh
    else
      ui_print "! $PROP is Unsupported."
      ui_print "  in $FILE"
    fi
  fi
  PROP=`grep_prop zram.prio $ZRAM`
  if [ "$PROP" ]; then
    ui_print "- Modifying Swap Priority $PROP..."
    sed -i "s|PRIO=0|PRIO=$PROP|g" $MODPATH/service.sh
  else
    ui_print "- Modifying Swap Priority to 0..."
    ui_print "- To 0..."
  fi
fi
PROP=`grep_prop zram.sflp $ZRAM`
if [ "$PROP" ]; then
  if [ "$PROP" -gt 100 ]; then
    PROP=100
  elif [ "$PROP" -lt 0 ]; then
    unset PROP
  fi
fi
if [ "$PROP" ]; then
  ui_print "- Modifying swap_free_low_percentage..."
  ui_print "- To $PROP"
  sed -i "s|SFLP=0|SFLP=$PROP|g" $MODPATH/service.sh
else
  ui_print "- Modifying swap_free_low_percentage..."
  ui_print "- To 0..."
  ui_print "- Completed."
fi

# Completions
ui_print ""
ui_print "- Scripts executions completed - Root Module is installed."
ui_print "- Please REBOOT/RESTART the Device for effects."
ui_print ""
ui_print "- ADDITIONAL NOTES:"
ui_print "- MAKE USE OF THE ROOT MODULE AT YOUR OWN RISKS."
ui_print "- DEVELOPERS ARE NOT TOOK RESPONSIBILITY FOR WHAT HAPPENED ONLY IF IS YOUR FAULTS."
ui_print ""
# Log the date and time
echo "- Time of execution: $(date)"

# Notes
ui_print ""
ui_print "- It will take some time."
ui_print "- Please wait and be patience until is completed."

# Installations
ui_print ""
ui_print "- Preparing..."
ui_print "- Installing..."

# Completions
ui_print ""
ui_print "- Root Module is installed."
ui_print "- Please REBOOT/RESTART the Device for effects."
ui_print ""
ui_print "- ADDITIONAL NOTES:"
ui_print "- MAKE USE OF THE ROOT MODULE AT YOUR OWN RISKS."
ui_print "- DEVELOPERS ARE NOT TOOK RESPONSIBILITY FOR WHAT HAPPENED ONLY IF IS YOUR FAULTS."
ui_print ""